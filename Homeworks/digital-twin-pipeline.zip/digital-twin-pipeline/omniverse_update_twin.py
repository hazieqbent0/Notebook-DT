"""
omniverse_update_twin.py

Run this INSIDE Omniverse (Script Editor window, or as the core of a Basic
Python extension's on_startup). It polls the same InfluxDB `twin_state`
measurement the Grafana dashboard reads from, and drives a USD prim's
translate + rotate attributes from the live digital twin data.

Prerequisites in the Omniverse stage:
  - A prim at /World/TwinObject (any mesh - a Cube works fine for testing).
    Create one via: Create > Mesh > Cube, then rename/move it to /World/TwinObject.

This demonstrates:
  - Reading from the SAME data store as Grafana (twin_state measurement).
  - Periodic polling (POLL_INTERVAL, matching the simulator's WRITE_INTERVAL).
  - Updating BOTH translation (x, y, z) and orientation (yaw) on each poll.
"""

import asyncio

import omni.usd
from pxr import Gf, UsdGeom
from influxdb_client import InfluxDBClient

# --- Connection settings (match docker-compose.yml / simulator.py) ---
INFLUX_URL = "http://localhost:8086"
INFLUX_TOKEN = "my-super-secret-token"
INFLUX_ORG = "digitaltwin"
INFLUX_BUCKET = "twin_data"

# --- Prim to drive ---
PRIM_PATH = "/World/TwinObject"

# --- Poll interval: should be <= the simulator's WRITE_INTERVAL (1s) to
#     avoid missing updates. Matches the Grafana refresh justification. ---
POLL_INTERVAL = 1.0  # seconds

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
query_api = client.query_api()

_LATEST_QUERY = f'''
from(bucket: "{INFLUX_BUCKET}")
  |> range(start: -10s)
  |> filter(fn: (r) => r._measurement == "twin_state")
  |> filter(fn: (r) => r._field == "x" or r._field == "y" or r._field == "z" or r._field == "yaw")
  |> last()
'''


def fetch_latest_twin_state():
    """Query InfluxDB for the most recent x, y, z, yaw values."""
    tables = query_api.query(_LATEST_QUERY, org=INFLUX_ORG)
    values = {}
    for table in tables:
        for record in table.records:
            values[record.get_field()] = record.get_value()
    if all(k in values for k in ("x", "y", "z", "yaw")):
        return values["x"], values["y"], values["z"], values["yaw"]
    return None


def apply_transform(x: float, y: float, z: float, yaw_deg: float) -> None:
    """Update the prim's translate + rotateZ (orientation/yaw) attributes."""
    stage = omni.usd.get_context().get_stage()
    prim = stage.GetPrimAtPath(PRIM_PATH)
    if not prim.IsValid():
        print(f"[digital-twin] Prim not found at {PRIM_PATH}. "
              f"Create a mesh there first (e.g. a Cube).")
        return

    xform = UsdGeom.Xformable(prim)
    xform.ClearXformOpOrder()

    translate_op = xform.AddTranslateOp()
    translate_op.Set(Gf.Vec3d(x, y, z))

    rotate_op = xform.AddRotateZOp()
    rotate_op.Set(yaw_deg)


async def poll_loop():
    print(f"[digital-twin] Polling {INFLUX_BUCKET}.twin_state every "
          f"{POLL_INTERVAL}s -> driving {PRIM_PATH}")
    while True:
        state = fetch_latest_twin_state()
        if state:
            x, y, z, yaw = state
            apply_transform(x, y, z, yaw)
            print(f"[digital-twin] Updated -> pos=({x:.2f},{y:.2f},{z:.2f}) yaw={yaw:.1f}")
        else:
            print("[digital-twin] No twin_state data yet - is simulator.py running?")
        await asyncio.sleep(POLL_INTERVAL)


# Kick off the polling loop as an asyncio task inside Omniverse's event loop.
asyncio.ensure_future(poll_loop())
