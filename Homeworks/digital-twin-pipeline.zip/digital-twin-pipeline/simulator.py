"""
Digital twin + sensor data simulator.

Writes two distinct measurements to InfluxDB every WRITE_INTERVAL seconds:
  - sensor_data : raw sensor stream (temperature, vibration)
  - twin_state  : digital twin state (position x/y/z, yaw orientation)

This single interval (WRITE_INTERVAL) is the ground truth you cite later
when justifying the Grafana dashboard refresh rate.
"""

import math
import random
import time

from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

# --- Connection settings (match docker-compose.yml) ---
INFLUX_URL = "http://localhost:8086"
INFLUX_TOKEN = "my-super-secret-token"
INFLUX_ORG = "digitaltwin"
INFLUX_BUCKET = "twin_data"

# --- Simulation settings ---
WRITE_INTERVAL = 1.0  # seconds between writes - THE update-period ground truth

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = client.write_api(write_options=SYNCHRONOUS)


def generate_sensor_reading(t: float) -> tuple[float, float]:
    """Simulate a noisy temperature + vibration sensor stream."""
    temperature = 22 + 3 * math.sin(t / 10) + random.uniform(-0.3, 0.3)
    vibration = 0.5 + 0.2 * math.sin(t / 3) + random.uniform(-0.05, 0.05)
    return temperature, vibration


def generate_twin_state(t: float) -> tuple[float, float, float, float]:
    """Simulate a digital twin object moving in a circle at height 1.0,
    continuously rotating (yaw)."""
    x = 5 * math.cos(t / 20)
    y = 5 * math.sin(t / 20)
    z = 1.0
    yaw = (t * 5) % 360
    return x, y, z, yaw


def main() -> None:
    t = 0.0
    print(f"Writing to {INFLUX_BUCKET} every {WRITE_INTERVAL}s. Ctrl+C to stop.")
    try:
        while True:
            temperature, vibration = generate_sensor_reading(t)
            x, y, z, yaw = generate_twin_state(t)

            sensor_point = (
                Point("sensor_data")
                .field("temperature", temperature)
                .field("vibration", vibration)
            )
            twin_point = (
                Point("twin_state")
                .field("x", x)
                .field("y", y)
                .field("z", z)
                .field("yaw", yaw)
            )

            write_api.write(bucket=INFLUX_BUCKET, record=[sensor_point, twin_point])

            print(
                f"t={t:6.0f}s | temp={temperature:6.2f}C vib={vibration:5.2f} "
                f"| pos=({x:5.2f},{y:5.2f},{z:4.2f}) yaw={yaw:6.1f}"
            )

            t += WRITE_INTERVAL
            time.sleep(WRITE_INTERVAL)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        write_api.close()
        client.close()


if __name__ == "__main__":
    main()
